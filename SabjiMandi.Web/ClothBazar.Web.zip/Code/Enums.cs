﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClothBazar.Web.Code
{
    public enum SortByEnum
    {
        Default = 1,
        Popularity= 2,
        PriceLowToHigh = 3,
        PriceHighToLow = 4, 
    }
}